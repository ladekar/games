
#!/usr/bin/env python3
"""
Safe Internship Application Copilot
-----------------------------------
What it does:
- Reads a plain-text resume
- Reads a CSV of public job URLs
- Downloads each job page
- Extracts likely title/company/location/description
- Scores job fit based on resume + internship/AI/ML/SWE keywords
- Generates:
    * outputs/job_results.csv
    * outputs/emails/<slug>.txt
    * outputs/cover_letters/<slug>.txt
    * outputs/linkedin_msgs/<slug>.txt

What it does NOT do:
- No auto-submission
- No login automation
- No CAPTCHA handling
- No bypassing site restrictions

Python version: 3.10+
Dependencies: none outside standard library
"""

from __future__ import annotations

import csv
import html
import json
import os
import re
import sys
import time
import hashlib
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Dict, Tuple
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError


# ----------------------------
# Configuration
# ----------------------------

USER_NAME = "Sharvali Ladekar"
USER_EMAIL = "sladekar@purdue.edu"
USER_PHONE = "(919) 593-7157"
USER_SCHOOL = "Purdue University"
USER_MAJOR = "Computer Science"
USER_FOCUS = "Artificial Intelligence and Machine Learning"
USER_LINKEDIN = "linkedin.com/in/sharvali-ladekar"
USER_GITHUB = "GitHub"

REQUEST_TIMEOUT_SECONDS = 20
REQUEST_DELAY_SECONDS = 1.0

KEYWORDS_CORE = {
    "python": 5,
    "java": 4,
    "c++": 3,
    "c": 2,
    "javascript": 3,
    "sql": 3,
    "r": 2,
    "machine learning": 7,
    "ml": 4,
    "artificial intelligence": 7,
    "ai": 4,
    "llm": 7,
    "large language model": 7,
    "data pipeline": 5,
    "databricks": 4,
    "airflow": 4,
    "security": 4,
    "cybersecurity": 4,
    "analytics": 3,
    "research": 3,
    "jupyter": 2,
    "git": 2,
    "linux": 2,
    "feature engineering": 4,
    "decision trees": 3,
    "k-means": 3,
    "regression": 3,
    "agentic ai": 4,
    "prompt engineering": 3,
    "evaluation pipelines": 3,
}

KEYWORDS_INTERNSHIP_BOOST = {
    "intern": 8,
    "internship": 8,
    "undergraduate": 8,
    "student": 6,
    "new grad": -6,
    "senior": -10,
    "staff": -12,
    "principal": -12,
    "manager": -12,
    "director": -15,
    "phd required": -8,
    "masters required": -5,
}

DOMAIN_HINTS = {
    "jobs.lever.co": "Lever",
    "greenhouse.io": "Greenhouse",
    "ashbyhq.com": "Ashby",
    "workday": "Workday",
    "smartrecruiters.com": "SmartRecruiters",
    "myworkdayjobs.com": "Workday",
}

STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "have", "has", "you",
    "your", "our", "are", "will", "into", "using", "use", "used", "their",
    "they", "them", "about", "work", "team", "role", "job", "position", "apply",
    "application", "candidate", "internship", "intern", "student", "experience",
    "skills", "responsibilities", "requirements", "preferred", "qualifications"
}


# ----------------------------
# Data classes
# ----------------------------

@dataclass
class JobRecord:
    url: str
    title: str = ""
    company: str = ""
    location: str = ""
    description: str = ""
    source_platform: str = ""
    score: float = 0.0
    matched_keywords: str = ""
    internship_likelihood: str = ""
    notes: str = ""
    slug: str = ""


# ----------------------------
# Utility functions
# ----------------------------

def read_text_file(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore").strip()

def ensure_dirs(base: Path) -> Dict[str, Path]:
    outputs = base / "outputs"
    emails = outputs / "emails"
    cover_letters = outputs / "cover_letters"
    linkedin_msgs = outputs / "linkedin_msgs"
    cache = outputs / "cache"

    for d in (outputs, emails, cover_letters, linkedin_msgs, cache):
        d.mkdir(parents=True, exist_ok=True)

    return {
        "outputs": outputs,
        "emails": emails,
        "cover_letters": cover_letters,
        "linkedin_msgs": linkedin_msgs,
        "cache": cache,
    }

def normalize_text(text: str) -> str:
    text = html.unescape(text)
    text = re.sub(r"(?is)<script.*?>.*?</script>", " ", text)
    text = re.sub(r"(?is)<style.*?>.*?</style>", " ", text)
    text = re.sub(r"(?s)<!--.*?-->", " ", text)
    text = re.sub(r"(?is)<[^>]+>", " ", text)
    text = text.replace("\xa0", " ")
    text = re.sub(r"\s+", " ", text)
    return text.strip()

def strip_html_title(html_text: str) -> str:
    m = re.search(r"(?is)<title[^>]*>(.*?)</title>", html_text)
    return normalize_text(m.group(1)) if m else ""

def slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    text = re.sub(r"-+", "-", text).strip("-")
    return text[:80] or "job"

def domain_platform(url: str) -> str:
    host = urlparse(url).netloc.lower()
    for hint, platform in DOMAIN_HINTS.items():
        if hint in host:
            return platform
    return host

def fetch_url(url: str, cache_dir: Path) -> str:
    key = hashlib.sha256(url.encode("utf-8")).hexdigest()[:20]
    cache_path = cache_dir / f"{key}.html"

    if cache_path.exists():
        return cache_path.read_text(encoding="utf-8", errors="ignore")

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (compatible; InternshipApplicationCopilot/1.0; "
            "+https://example.local)"
        )
    }
    req = Request(url, headers=headers)
    with urlopen(req, timeout=REQUEST_TIMEOUT_SECONDS) as resp:
        content_type = resp.headers.get("Content-Type", "")
        raw = resp.read()
        try:
            charset = resp.headers.get_content_charset() or "utf-8"
        except Exception:
            charset = "utf-8"
        text = raw.decode(charset, errors="ignore")

        # Store cache
        cache_path.write_text(text, encoding="utf-8", errors="ignore")
        return text

def extract_meta(html_text: str, name: str = "", prop: str = "") -> str:
    patterns = []
    if name:
        patterns.append(
            rf'(?is)<meta[^>]+name=["\']{re.escape(name)}["\'][^>]+content=["\'](.*?)["\']'
        )
        patterns.append(
            rf'(?is)<meta[^>]+content=["\'](.*?)["\'][^>]+name=["\']{re.escape(name)}["\']'
        )
    if prop:
        patterns.append(
            rf'(?is)<meta[^>]+property=["\']{re.escape(prop)}["\'][^>]+content=["\'](.*?)["\']'
        )
        patterns.append(
            rf'(?is)<meta[^>]+content=["\'](.*?)["\'][^>]+property=["\']{re.escape(prop)}["\']'
        )
    for p in patterns:
        m = re.search(p, html_text)
        if m:
            return normalize_text(m.group(1))
    return ""

def extract_json_ld(html_text: str) -> List[dict]:
    blocks = re.findall(
        r'(?is)<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        html_text
    )
    results = []
    for block in blocks:
        block = block.strip()
        if not block:
            continue
        try:
            data = json.loads(block)
            if isinstance(data, list):
                results.extend(x for x in data if isinstance(x, dict))
            elif isinstance(data, dict):
                results.append(data)
        except json.JSONDecodeError:
            continue
    return results

def extract_job_from_json_ld(items: List[dict]) -> Dict[str, str]:
    out = {"title": "", "company": "", "location": "", "description": ""}
    for item in items:
        item_type = item.get("@type", "")
        if isinstance(item_type, list):
            types = [str(x).lower() for x in item_type]
        else:
            types = [str(item_type).lower()]
        if "jobposting" not in types:
            continue

        out["title"] = normalize_text(str(item.get("title", "")))
        hiring_org = item.get("hiringOrganization", {})
        if isinstance(hiring_org, dict):
            out["company"] = normalize_text(str(hiring_org.get("name", "")))

        loc = item.get("jobLocation", {})
        if isinstance(loc, list) and loc:
            loc = loc[0]
        if isinstance(loc, dict):
            addr = loc.get("address", {})
            if isinstance(addr, dict):
                pieces = [
                    addr.get("addressLocality", ""),
                    addr.get("addressRegion", ""),
                    addr.get("addressCountry", ""),
                ]
                out["location"] = ", ".join([p for p in pieces if p])

        out["description"] = normalize_text(str(item.get("description", "")))
        return out
    return out

def extract_visible_text(html_text: str) -> str:
    return normalize_text(html_text)

def find_first_match(text: str, patterns: List[str]) -> str:
    for p in patterns:
        m = re.search(p, text, re.I | re.S)
        if m:
            return normalize_text(m.group(1))
    return ""

def extract_basic_fields(url: str, html_text: str) -> JobRecord:
    json_ld = extract_json_ld(html_text)
    job_json = extract_job_from_json_ld(json_ld)
    title_tag = strip_html_title(html_text)
    og_title = extract_meta(html_text, prop="og:title")
    og_desc = extract_meta(html_text, prop="og:description")
    desc_meta = extract_meta(html_text, name="description")

    visible = extract_visible_text(html_text)

    title = (
        job_json["title"]
        or og_title
        or find_first_match(visible, [
            r"\bjob title[:\s]+(.{1,120})",
            r"\bposition[:\s]+(.{1,120})",
        ])
        or title_tag
    )

    company = (
        job_json["company"]
        or find_first_match(visible, [
            r"\bcompany[:\s]+(.{1,120})",
            r"\babout\s+([A-Z][A-Za-z0-9&,\-\. ]{2,80})",
        ])
    )

    location = (
        job_json["location"]
        or find_first_match(visible, [
            r"\blocation[:\s]+(.{1,120})",
            r"\bremote\b",
            r"\bhybrid\b",
            r"\bon-site\b",
        ])
    )

    description = (
        job_json["description"]
        or og_desc
        or desc_meta
        or visible[:12000]
    )

    # Light cleanup for titles like "Job Title | Company"
    if not company and "|" in title:
        parts = [p.strip() for p in title.split("|")]
        if len(parts) >= 2:
            title, company = parts[0], parts[1]

    title = title[:200]
    company = company[:120]
    location = location[:120]
    description = description[:20000]

    slug_base = f"{company}-{title}" if company else title or url
    slug = slugify(slug_base)

    return JobRecord(
        url=url,
        title=title,
        company=company,
        location=location,
        description=description,
        source_platform=domain_platform(url),
        slug=slug,
    )

def tokenize(text: str) -> List[str]:
    text = text.lower()
    text = re.sub(r"[^a-z0-9\+\# ]+", " ", text)
    tokens = [t for t in text.split() if len(t) > 1]
    return tokens

def keyword_counts(text: str, weighted_keywords: Dict[str, int]) -> Tuple[float, List[str]]:
    text_lower = text.lower()
    score = 0.0
    matches = []
    for phrase, weight in weighted_keywords.items():
        count = len(re.findall(rf"\b{re.escape(phrase.lower())}\b", text_lower))
        if count > 0:
            score += weight * min(count, 3)
            matches.append(phrase)
    return score, matches

def internship_likelihood(text: str) -> str:
    text_lower = text.lower()
    positive = 0
    negative = 0

    for phrase, weight in KEYWORDS_INTERNSHIP_BOOST.items():
        count = len(re.findall(rf"\b{re.escape(phrase.lower())}\b", text_lower))
        if count:
            if weight > 0:
                positive += weight
            else:
                negative += abs(weight)

    if positive >= 8 and negative <= 5:
        return "high"
    if positive >= 4 and negative <= 10:
        return "medium"
    return "low"

def top_resume_signals(resume_text: str) -> List[str]:
    ranked = []
    text_lower = resume_text.lower()
    for phrase, weight in sorted(KEYWORDS_CORE.items(), key=lambda x: -x[1]):
        if phrase in text_lower:
            ranked.append(phrase)
    return ranked[:8]

def extract_focus_terms(job_text: str, limit: int = 10) -> List[str]:
    tokens = tokenize(job_text)
    freq: Dict[str, int] = {}
    for tok in tokens:
        if tok in STOPWORDS or tok.isdigit():
            continue
        if len(tok) < 3:
            continue
        freq[tok] = freq.get(tok, 0) + 1

    common = sorted(freq.items(), key=lambda x: (-x[1], x[0]))
    out = [w for w, _ in common[:50]]

    # Keep likely tech words / internship words first
    preferred = []
    for w in out:
        if w in {
            "python", "java", "javascript", "sql", "linux", "cloud", "aws",
            "gcp", "api", "apis", "backend", "frontend", "security", "ml",
            "ai", "data", "research", "distributed", "systems", "analytics",
            "automation", "testing", "networking", "infrastructure"
        }:
            preferred.append(w)

    merged = preferred + [w for w in out if w not in preferred]
    return merged[:limit]

def score_job(job: JobRecord, resume_text: str) -> JobRecord:
    combined = f"{job.title}\n{job.company}\n{job.location}\n{job.description}"
    core_score, core_matches = keyword_counts(combined, KEYWORDS_CORE)
    intern_score, intern_matches = keyword_counts(combined, KEYWORDS_INTERNSHIP_BOOST)

    # Resume overlap
    resume_signals = top_resume_signals(resume_text)
    overlap = []
    combined_lower = combined.lower()
    overlap_score = 0.0
    for s in resume_signals:
        if s in combined_lower:
            overlap.append(s)
            overlap_score += 5.0

    # Internship penalty/boost
    likelihood = internship_likelihood(combined)

    total = core_score + overlap_score + intern_score

    # Light sanity adjustments
    if likelihood == "high":
        total += 10
    elif likelihood == "medium":
        total += 3
    else:
        total -= 8

    title_lower = job.title.lower()
    if "intern" in title_lower or "student" in title_lower:
        total += 12
    if any(x in title_lower for x in ("senior", "staff", "principal", "manager", "director")):
        total -= 20

    job.score = round(total, 1)
    job.matched_keywords = ", ".join(sorted(set(core_matches + overlap + intern_matches)))[:500]
    job.internship_likelihood = likelihood
    return job

def summarize_fit(job: JobRecord, resume_text: str) -> str:
    signals = top_resume_signals(resume_text)
    focus = extract_focus_terms(job.description)
    shared = [s for s in signals if s in job.description.lower()][:5]

    parts = []
    if shared:
        parts.append("Strong overlap in " + ", ".join(shared))
    if "security" in job.description.lower() and "security" in resume_text.lower():
        parts.append("resume includes security analytics experience")
    if "research" in job.description.lower():
        parts.append("research experience is relevant")
    if "python" in job.description.lower():
        parts.append("Python background aligns well")
    if "llm" in job.description.lower() or "large language" in job.description.lower():
        parts.append("LLM experience is a differentiator")

    if not parts:
        parts.append("general software and AI background appears relevant")

    tail = ", ".join(focus[:5]) if focus else "software engineering, AI, data"
    return f"{'; '.join(parts)}. Focus terms detected: {tail}."

def tailored_interest_line(job: JobRecord) -> str:
    text = f"{job.title} {job.description}".lower()

    if any(x in text for x in ("machine learning", "artificial intelligence", "llm", "ai ")):
        return "I’m particularly interested in applying AI/ML and LLM engineering skills to real-world systems."
    if any(x in text for x in ("security", "cyber", "threat", "detection")):
        return "I’m particularly interested in contributing to security-focused systems and analytics."
    if any(x in text for x in ("data", "pipeline", "analytics", "warehouse")):
        return "I’m particularly interested in building data-driven systems and scalable engineering workflows."
    if any(x in text for x in ("distributed", "infrastructure", "backend", "systems", "network")):
        return "I’m particularly interested in distributed systems, backend engineering, and infrastructure at scale."
    return "I’m particularly interested in applying my software engineering and AI background to impactful technical work."

def build_email(job: JobRecord) -> str:
    company = job.company or "Hiring Team"
    title = job.title or "Internship Role"
    interest = tailored_interest_line(job)

    return f"""Subject: Interest in {title}

Dear {company} Hiring Team,

I hope you are doing well.

I am writing to express my interest in the {title} opportunity. I am currently a sophomore at {USER_SCHOOL} pursuing a degree in {USER_MAJOR} with a focus on {USER_FOCUS}.

My background includes Python, Java, machine learning workflows, data analysis, and AI-assisted software engineering. I have also worked on security analytics research involving domain telemetry and malicious DNS tunneling detection, along with experience using modern LLM tools in development workflows.

{interest}

I would be grateful for the opportunity to be considered for this role. My resume is attached, and I would welcome the chance to discuss how my background could support your team.

Thank you for your time and consideration.

Sincerely,
{USER_NAME}
{USER_EMAIL}
{USER_PHONE}
{USER_LINKEDIN}
""".strip()

def build_cover_letter(job: JobRecord) -> str:
    company = job.company or "the company"
    title = job.title or "internship position"
    interest = tailored_interest_line(job)

    return f"""Dear Hiring Team,

I am excited to apply for the {title} at {company}. I am a sophomore at {USER_SCHOOL} studying {USER_MAJOR} with a focus on {USER_FOCUS}, and I am eager to contribute to meaningful engineering work while continuing to grow as a developer.

My experience includes machine learning workflows, cybersecurity analytics, and AI-assisted software engineering. In my current undergraduate data science research role, I analyze large-scale domain telemetry datasets to detect malicious DNS tunneling patterns, develop Python-based ML workflows, and apply feature engineering to improve threat detection quality. I also have experience working with LLM-based development workflows, token-efficient prompting, and AI-powered engineering tools.

{interest}

What especially draws me to {company} is the chance to work on real systems with practical impact. I enjoy learning quickly, collaborating closely, and turning technical ideas into working solutions. I would be excited to bring that mindset, along with my background in Python, Java, machine learning, and data-driven problem solving, to your team.

Thank you for your consideration. I would value the opportunity to discuss my background further.

Sincerely,
{USER_NAME}
""".strip()

def build_linkedin_message(job: JobRecord) -> str:
    company = job.company or "your company"
    title = job.title or "an internship role"
    return (
        f"Hi [Name], I recently applied for {title} at {company} and wanted to reach out. "
        f"I’m a Purdue CS student focused on AI/ML with experience in ML pipelines, "
        f"LLM-based systems, and data workflows. I’d love to contribute and would really "
        f"appreciate any guidance you can share!"
    )

def load_jobs_csv(path: Path) -> List[str]:
    urls = []
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        if "url" not in reader.fieldnames:
            raise ValueError("jobs.csv must contain a 'url' column")
        for row in reader:
            url = (row.get("url") or "").strip()
            if url:
                urls.append(url)
    return urls

def save_results_csv(path: Path, jobs: List[JobRecord]) -> None:
    fieldnames = list(asdict(jobs[0]).keys()) if jobs else [
        "url", "title", "company", "location", "description", "source_platform",
        "score", "matched_keywords", "internship_likelihood", "notes", "slug"
    ]
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for job in jobs:
            row = asdict(job)
            # Keep CSV manageable
            row["description"] = row["description"][:2500]
            writer.writerow(row)

def main() -> int:
    base = Path.cwd()
    resume_path = base / "resume.txt"
    jobs_path = base / "jobs.csv"

    if not resume_path.exists():
        print("Missing resume.txt")
        return 1
    if not jobs_path.exists():
        print("Missing jobs.csv")
        return 1

    dirs = ensure_dirs(base)
    resume_text = read_text_file(resume_path)
    urls = load_jobs_csv(jobs_path)

    jobs: List[JobRecord] = []

    for idx, url in enumerate(urls, start=1):
        print(f"[{idx}/{len(urls)}] Processing {url}")
        try:
            html_text = fetch_url(url, dirs["cache"])
            job = extract_basic_fields(url, html_text)
            job = score_job(job, resume_text)
            job.notes = summarize_fit(job, resume_text)

            email_text = build_email(job)
            cover_text = build_cover_letter(job)
            linkedin_text = build_linkedin_message(job)

            (dirs["emails"] / f"{job.slug}.txt").write_text(email_text, encoding="utf-8")
            (dirs["cover_letters"] / f"{job.slug}.txt").write_text(cover_text, encoding="utf-8")
            (dirs["linkedin_msgs"] / f"{job.slug}.txt").write_text(linkedin_text, encoding="utf-8")

            jobs.append(job)
            time.sleep(REQUEST_DELAY_SECONDS)

        except (HTTPError, URLError, TimeoutError) as e:
            jobs.append(JobRecord(
                url=url,
                source_platform=domain_platform(url),
                notes=f"Fetch failed: {e}",
                internship_likelihood="unknown",
                slug=slugify(url),
            ))
        except Exception as e:
            jobs.append(JobRecord(
                url=url,
                source_platform=domain_platform(url),
                notes=f"Unexpected error: {type(e).__name__}: {e}",
                internship_likelihood="unknown",
                slug=slugify(url),
            ))

    jobs.sort(key=lambda j: j.score, reverse=True)
    save_results_csv(dirs["outputs"] / "job_results.csv", jobs)

    print("\nDone.")
    print(f"Results CSV: {dirs['outputs'] / 'job_results.csv'}")
    print(f"Emails:      {dirs['emails']}")
    print(f"Cover letters:{dirs['cover_letters']}")
    print(f"Messages:    {dirs['linkedin_msgs']}")

    # Print top 10 summary
    print("\nTop matches:")
    for job in jobs[:10]:
        print(
            f"- score={job.score:>5} | {job.company[:25]:25} | "
            f"{job.title[:45]:45} | {job.url}"
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())